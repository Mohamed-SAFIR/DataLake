from django.contrib import admin
from .models import *
from import_export.admin import ImportExportModelAdmin

# Models that are going to be shown in the admin part

@admin.register(Station)
class PostImportExport(ImportExportModelAdmin):
    pass

# @admin.register(Latitude)
# class PostImportExport(ImportExportModelAdmin):
#     pass

@admin.register(TmpFinal)
class PostImportExport(ImportExportModelAdmin):
    pass

@admin.register(TmpFinalJour)
class PostImportExport(ImportExportModelAdmin):
    pass

@admin.register(AvgStation)
class PostImportExport(ImportExportModelAdmin):
    pass

@admin.register(TmpAnnee)
class PostImportExport(ImportExportModelAdmin):
    pass

# @admin.register(TmpFinalSaison)
# class PostImportExport(ImportExportModelAdmin):
#     pass

# @admin.register(TmpFinalMoi)
# class PostImportExport(ImportExportModelAdmin):
#     pass


