from distutils.log import debug
from django.core import serializers
from datetime import datetime
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from .models import *
import json
# Create your views here.

def essai_view(request):
    stations = TmpFinal.objects.all()
    pays = TmpAnnee.objects.all()
    annee = TmpAnnee.objects.all()
    if request.method == "POST":
        stations = request.POST.get("select_station_name")
        pays = request.POST.get("select_pays_name")
        annee = request.POST.get("select_annee_name")
    context = {
        "stations": stations,
        "pays": pays,
        "annee": annee,
    }
    return render(request, 'index.html', context)




def test(request, station):

    if request.method == "POST" and request:
        stations = TmpFinal.objects.filter(STATION=station)
        data_toSerialize = serializers.serialize("json", queryset=stations)
        data_serialize = json.loads(data_toSerialize)
        return JsonResponse({"data": data_serialize})

def testAnnee(request, pays):
    
    if request.method == "POST" and request:
        pays = TmpAnnee.objects.filter(PAYS=pays)
        data_toSerialize = serializers.serialize("json", queryset=pays)
        data_serialize = json.loads(data_toSerialize)
        return JsonResponse({"data": data_serialize})
    
    
    
def indexStation(request):
    station_data = TmpFinal.objects.all()
    station = TmpFinal.objects.values('station').distinct()
    name = TmpFinal.objects.values('station_name').distinct()
    latitude = TmpFinal.objects.values('station_latitude').distinct()
    longitude = TmpFinal.objects.values('station_longitude').distinct()
    moyenne = TmpFinal.objects.values('station_moyenne').distinct()
    
    if request.method == "POST":
        station = request.POST.get("STATION")
        name = request.POST.get("station_name")
        longitude = request.POST.get("station_longitude")
        latitude = request.POST.get("station_latitude")
        moyenne = request.POST.get("station_moyenne")
        if station:
            try:
                station_data = TmpFinal.objects.get(station=station)
                return redirect('filtresMeteo', pk1=station)
            except:
                return redirect ('index')
    context = {
        "station_data": station_data,
        "stations": station,
    }
    return render(request, 'index.html', context)


def filtresMeteo(request, pk1):
    station_data = TmpFinal.objects.get(station=pk1)
    context = {
        "station_data": station_data
    }
    return render(request, 'filtres_meteo.html', context)