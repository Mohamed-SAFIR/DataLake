function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
  
  
function getAllStationDetails(station){
    let csrftoken = getCookie('csrftoken')
    $.ajax({
        type: "POST",
        url: `test/${station}/`,
        headers:{
            'Content-type':'application/json',
            'X-CSRFToken':csrftoken,
        },
        data: {},
        success: function(response) {
            let data = response["data"];
            // console.log(response["data"]);
            // leaflet(data)
            afficher(data)
        },
    });

}


function getAllStationDetailsOnChnage(){
    let selectedCountryValue
    let selectedCountry = document.getElementById('inputGroupSelect1');
    selectedCountry.addEventListener('change', function() {
        $("#inputGroupSelect1 option:selected").each(function () {
            selectedCountryValue = $(this).val();
            (getAllStationDetails(selectedCountryValue));
        });
       
    });
}



  
function afficheDetails(data) {
    let element = "<div class=\"card border-0 shadow logs-card\" style=\"width: 100%; margin-top: 3.5%; \">\n"
    element +="                    <div class=\"card-body\">\n"
    element +="                        <h5 class=\"card-title\">"  + data.station_name + "</h5>\n"
    element +="                       <h6 class=\"card-subtitle mb-2 text-muted\">" + data.station_id + "</h6>\n"
    element +="                       <p class=\"card-text\">" + " <i class=\"fas fa-temperature-high\"></i> " + "<b>Température : </b>" + data.tmp_measure + "°" + "</p>\n"
    element +="                       <p class=\"card-text\">"+ " <i class=\"fa fa-wind\"></i> "  + "<b>Vitesse du vent : </b>" + data.wind_measure + "km/h" + "</p>\n"
    element +="                    </div>\n"
    element +="                </div>";
    return element
}

$(document).ready(function () {
    getAllWeatherDetails();
    getAllStationDetailsOnChnage();
  
})




