from django.db import models
  

class Station(models.Model):
    station_name = models.CharField(max_length=30)
    station_date = models.CharField(max_length=30)

# class Latitude(models.Model):
#     atitude_n = models.CharField(max_length=50)


class TmpFinal(models.Model):
    STATION = models.CharField(max_length=50)
    NAME = models.CharField(max_length=50)
    LONGITUDE = models.CharField(max_length=50)
    LATITUDE = models.CharField(max_length=50)
    Moyenne_TMP_station = models.CharField(max_length=50)

# PAR STATION 
class TmpFinalJour(models.Model):
    avg_jour = models.CharField(max_length=50)
    num_station  = models.CharField(max_length=50)
    nom_station = models.CharField(max_length=50)
    tmps_latitude = models.CharField(max_length=50)
    tmps_longitude = models.CharField(max_length=50)
    tmps_jour = models.CharField(max_length=50)
    tmps_mois = models.CharField(max_length=50)
    tmps_annee = models.CharField(max_length=50)

#PAR STATION ET ANNEE
class AvgStation(models.Model):
    STATION = models.CharField(max_length=50)
    NAME  = models.CharField(max_length=50)
    LONGITUDE = models.CharField(max_length=50)
    LATITUDE = models.CharField(max_length=50)
    MAX_TMP = models.CharField(max_length=50)
    MIN_TMP2 = models.CharField(max_length=50)
    MOYENNE_TMP = models.CharField(max_length=50)
    
# tmp par annee
class TmpAnnee(models.Model):
    PAYS = models.CharField(max_length=50)
    ANNEE  = models.CharField(max_length=50)
    Moyenne_TMP_pays_annee = models.CharField(max_length=50)

    
# class TmpFinalMaxJour(models.Model):
#     avg_max_jour = models.CharField(max_length=50)
#     num_station  = models.CharField(max_length=50)
#     nom_station = models.CharField(max_length=50)
#     tmp_latitude = models.CharField(max_length=50)
#     tmp_longitude = models.CharField(max_length=50)
#     tmp_jour = models.CharField(max_length=50)
#     tmp_mois = models.CharField(max_length=50)
#     tmp_annee = models.CharField(max_length=50)
    
# class TmpFinalMinJour(models.Model):
#     avg_min_jour = models.CharField(max_length=50)
#     num_station  = models.CharField(max_length=50)
#     nom_station = models.CharField(max_length=50)
#     tmp_latitude = models.CharField(max_length=50)
#     tmp_longitude = models.CharField(max_length=50)
#     tmp_jour = models.CharField(max_length=50)
#     tmp_mois = models.CharField(max_length=50)
#     tmp_annee = models.CharField(max_length=50)