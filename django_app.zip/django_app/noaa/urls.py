from django.urls import path

from . import views

urlpatterns = [
    path('essai_view/', views.essai_view, name='essai_view'),
    path('<int:pk>/filtresMeteo/', views.indexStation, name='index'),
    path('test/<str:station>/', views.test, name='test'),
    path('testAnnee/<str:pays>/', views.testAnnee, name='testAnnee'),


]