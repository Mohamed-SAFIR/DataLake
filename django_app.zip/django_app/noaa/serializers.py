from .models import *
from rest_framework import serializers, fields


class StationSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Station
        fields = '__all__'
        

   
class TmpFinalSerializer(serializers.ModelSerializer):
    
     class Meta:
        model = TmpFinal
        fields = '__all__'
     
class TmpAnneeSerializer(serializers.ModelSerializer):
    
     class Meta:
        model = TmpAnnee
        fields = '__all__'


# class TmpFinalMoiSerializer(serializers.ModelSerializer):
    
#      class Meta:
#         model = TmpFinalMoi
#         fields = '__all__'
        

# class TmpFinalSaisonSerializer(serializers.ModelSerializer):
    
#      class Meta:
#         model = TmpFinalSaison
#         fields = '__all__'
        
# class TmpFinalMaxJourSerializer(serializers.ModelSerializer):
    
#      class Meta:
#         model = TmpFinalMaxJour
#         fields = '__all__'

# class TmpFinalMinJourSerializer(serializers.ModelSerializer):
    
#      class Meta:
#         model = TmpFinalMinJour
#         fields = '__all__'